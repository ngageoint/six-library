int test_main(int argc, char* argv[]);

#define main()		test_main(int argc, char* argv[])