#
# Copyright by The HDF Group.
# All rights reserved.
#
# This file is part of HDF5.  The full HDF5 copyright notice, including
# terms governing use, modification, and redistribution, is contained in
# the LICENSE file, which can be found at the root of the source code
# distribution tree, or in https://www.hdfgroup.org/licenses.
# If you do not have access to either file, you may request a copy from
# help@hdfgroup.org.
#
#########################################################################

# - Derived from the FindTiff.cmake and FindJPEG.cmake that is included with cmake
# FindMFU

# Find the native MFU includes and library

# Imported targets
##################

# This module defines the following :prop_tgt:`IMPORTED` targets:
#
# MFU::MFU
#  The MFU library, if found.
#
# Result variables
###################

# This module will set the following variables in your project:

#  MFU_FOUND, true if the MFU headers and libraries were found.
#  MFU_INCLUDE_DIR, the directory containing the MFU headers.
#  MFU_INCLUDE_DIRS, the directory containing the MFU headers.
#  MFU_LIBRARIES, libraries to link against to use MFU.

# Cache variables
#################

# The following variables may also be set:

#  MFU_LIBRARY, where to find the MFU library.
# message (STATUS "Finding MFU library and headers..." )
#########################################################################



FIND_PATH(MFU_INCLUDE_DIR
  NAMES mfu.h
  HINTS "$ENV{MFU_ROOT}/include"
)
FIND_LIBRARY(MFU_LIBRARY
  NAMES mfu
  HINTS "$ENV{MFU_ROOT}/lib64"
)

if(NOT MFU_LIBRARY)
  set(mfu_names ${MFU_NAMES} mfu libmfu)
  find_library(MFU_LIBRARY NAMES ${mfu_names})
  include(SelectLibraryConfigurations)
  select_library_configurations(MFU)
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(MFU
  REQUIRED_VARS MFU_LIBRARY MFU_INCLUDE_DIR)

if(MFU_FOUND)
  set(MFU_LIBRARIES "${MFU_LIBRARY}")
  set(MFU_INCLUDE_DIRS "${MFU_INCLUDE_DIR}")
  set(LL_PATH "$ENV{MFU_ROOT}/lib64:$ENV{MFU_ROOT}/lib")
  if(NOT TARGET MFU::MFU)
    add_library(MFU::MFU UNKNOWN IMPORTED)
    if(MFU_INCLUDE_DIRS)
      set_target_properties(MFU::MFU PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${MFU_INCLUDE_DIRS}")
    endif()
    if(EXISTS "${MFU_LIBRARY}")
      set_target_properties(MFU::MFU PROPERTIES
        IMPORTED_LINK_INTERFACE_LANGUAGES "C"
        IMPORTED_LOCATION "${MFU_LIBRARY}")
    endif()
  endif()
endif()

# Report the results.
if (NOT MFU_FOUND)
  message (FATAL_ERROR "MFU (mpiFileUtils) was not found. "
      "MFU is an HPC parallel file utilities library (https://github.com/hpc/mpifileutils). "
      "Set the MFU_ROOT environment variable to the install prefix (export MFU_ROOT=<path>), "
      "or set MFU_LIBRARY and MFU_INCLUDE_DIR explicitly. "
      "Note: HDF5_BUILD_PARALLEL_TOOLS also requires CIRCLE (libcircle, https://github.com/hpc/libcircle) "
      "and DTCMP (https://github.com/hpc/dtcmp), which are dependencies of mpiFileUtils and "
      "are expected to be installed under the same MFU_ROOT prefix."
  )
endif ()
