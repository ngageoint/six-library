/*
 * This file is intentionally empty.
 *
 * Before CMake 3.11, add_executable() and add_library() need
 * at least one source file.
 */
