This directory contains the (fledgling) test suite for Expat.  The
tests provide general unit testing and regression coverage.  The tests
are not expected to be useful examples of Expat usage; see the
examples/ directory for that.

The Expat tests use a partial internal implementation of the "Check"
unit testing framework for C. More information on Check can be found at:

        http://check.sourceforge.net/

Expat must be built and installed before "make check" can be executed.

Since both Check and this test suite are young, it can all change in a
later version.
