06-Jan-2012

vts command:
vtsTestThreads xmlfile.xml

Note: before thread testing, ensure that sensor model functions used 
in the thread testing will run succesfully: 
      initNITF21ISD, initNITF21ISD, initBytestreamISD, and/or initFilenameISD
      constructSensorModelFromISD
      getSensorModelName
      getReferencePoint
      imageToGround
      groundToImage
      computeGroundPartials
      getNumParameters
      computeSensorPartials

The vts command, vtsTestThreads, requires an xml file as an argument to be
   used for the thread test configuration.  This xml file is expected to be 
   located in the "data" directory. A sample xml file, ThreadTest.xml, is located
   in the "data" directory.

Here is the sample xml file, ThreadTest.xml:

   <ThreadTest>
      <Model PluginName="ExamplePlugin" SensorModelName="EXAMPLE_SENSOR_MODEL"></Model>
      <Test threads="2" points="20" runs ="5" oneSMPerThread="false">
         <image ISDFileType="NITF_21_TYPE" imageIndex="1">data/GHSarNITF21_good.ntf</image>
         <image ISDFileType="NITF_21_TYPE">data/GHSarNITF21_good.ntf</image>
         <image ISDFileType="NITF_20_TYPE" imageIndex="2">data/GHSarNITF20_good.ntf</image>
         <image ISDFileType="FILENAME_TYPE">data/GHSarNITF21_good.ntf</image>
         <image ISDFileType="BYTESTREAM_TYPE">data/GHSarNITF21_good.ntf</image>
         <image>data/GHSarNITF20_good.ntf</image>
      </Test>
   </ThreadTest>

XML file elements:
   "ThreadTest" - root element
   "Model" - attributes "PluginName" and "SensorModelName"
   "Test" - attributes "threads", "points", "runs", and "oneSMPerThread"
      threads - number of threads to create
      points - number of test points to use per image
      runs - number of tests to run for each thread
      oneSMPerThread - If true, construct a sensor model for each thread.
                       else construct one sm(for each image) for all threads.
   "image" - one or more: list of images, attributes "ISDFileType" and "imageIndex" 
      ISDFileType - NITF_21_TYPE, NITF_20_TYPE, FILENAME_TYPE, or BYTESTREAM_TYPE
                        (default FILENAME_TYPE)
      imageIndex - optional image index for NITF_21_TYPE and NITF_20_TYPE types
    


Thread Test processing flow:

for each image in image list,

  initalizeTestData:
    initialize ISD (NITF_21_TYPE, NITF_20_TYPE, FILENAME_TYPE, or BYTESTREAM_TYPE)
    construct sensor model
    getReferencePoint
    getImageSize
    for each point in number of test points
      random row column
      imageToGround row,column -> x, y, z
      groundToImage x,y,z -> line,sample
      computeGroundPartials x,y,z -> partials
      getNumParameters

      for each parameter
        computeSensorPartials x, y, z -> linePartial, sampPartial
     

for each thread
  for each number of test runs

    for each image in image list
      if g_oneSMPerThread
        construct sensor model
      else
        use model constructed in initalizeTestData for this image
      end if

      getReferencePoint
      for each point in number of test points
        imageToGround row,column -> x,y,z
        compare x,y,z with initialized

        groundToImage, x,y,z -> line, sample
        compare line, sample with initialized

        computeGroundPartials x,y,z -> partials
        compare partials with initialized

        getNumParameters

        for each parameter
          computeSensorPartials x, y, z -> linePartial, sampPartial
        
        compare all linePartials and sampPartials with initialized


