28-Jan-2013

VTS Version CSM3.0.1.0

PLEASE READ THE NOTES SECTION AT THE END OF THIS DOCUMENT!

If you have a problem or a question call me (Len Tomko  937-306-4262) or email me at 
leonard.tomko@gd-ais.com.
-----------------------------------------------------------------------------------------
This version of the VTS code is of a "unified" PC/UNIX source code. This release and
all future ones will be one combined release for both the PC and the UNIX distribution.
The source code is the same for both operating systems. Precompiler "if defs" are used to 
discriminate between platform specific code. The distribution will be made as a zip file.

The Makefiles are in the distribution for the UNIX build and C shell command scripts 
for running VTS scripts.

There are PC specific files in the distribution consisting of Microsoft compiler project 
file and command shell bat files.
-----------------------------------------------------------------------------------------
This version was built against CSM 3.0.1 API.
-----------------------------------------------------------------------------------------
The files have been placed in a zip file. To extract run "unzip filename.zip" in the 
directory you wish the files to reside. Where filename.zip is the name of the zip file.
-----------------------------------------------------------------------------------------
To compile the code use the Solaris "make" or the gcc "make gcc". Change directory 
to the top most vts directory (where the README_FIRST.txt file is located).

Run "make clean_all" followed by "make" or "make clean_all" followed by 
"make gcc" for the gcc compiler.

NOTE: running "make clean_all" will remove all binaries, executables, shared objects
and compiler cache files in the current directory and in all subdirectories.

To compile the code for Solaris using the gcc compiler "Makefile" use the commands:
make clean_gcc
make gcc

To compile the code for Linux use the commands:
make clean
make

To compile the code for windows use the load the solution file in the CSM
directory into Microsoft .NET 2003 C++ compiler.

-----------------------------------------------------------------------------------------

Getting started:
-----

-----------------------------------------------------------------------------------------
To run the test application enter:

vts

on the command line.
-----------------------------------------------------------------------------------------

The vts program will print out some information and pause with a prompt asking for a log
file. Enter a log file name then hit enter.
-----------------------------------------------------------------------------------------

The vts program will print out a "vts>" prompt.
At the prompt a vts command can be entered.
-----------------------------------------------------------------------------------------

The most useful command to execute at this point is the file read command i.e.
vts> vtsRead20ISDFile data/GHSarNITF20_good.ntf

The above command reads an NITF 2.0 file called GHSarNITF20_good.ntf.
-----------------------------------------------------------------------------------------

The next command to enter is "makeModelListFromISD plugin-name" i.e.

vts>makeModelListFromISD StubPlugin

The above command lets you select a plugin from the registered list of plugins.
-----------------------------------------------------------------------------------------

At the prompt other vts commands can be entered i.e.

vts>getManufacturer
-----------------------------------------------------------------------------------------

Enter "constructSensorModelFromISD StubPlugin" to enable the StubPlugin sensor model.
-----------------------------------------------------------------------------------------

At the prompt a vts command can be entered .i.e.

vts>groundToImage1 11 22 33 .01
-----------------------------------------------------------------------------------------

The "Stub" for groundToImage1 will prompt for return values which can be entered i.e.

StubSensorModel::groundToImage1>55.0 66.0 .77 0 0

See the comments at the top of the StubSensorModel.cpp file to explain the last two
parameters on the above line (i.e. 0 0).
-----------------------------------------------------------------------------------------
The "Stub" for groundToImage1 will prompt a second time for a return error message i.e.

StubSensorModel::groundToImage1>>No_Error
-----------------------------------------------------------------------------------------

To quit the vts type "exit" on the command line.

-----
Scripts:
-----
There is a test script directory that can be found at "./scripts/vts_test". 

To run a test script use command line redirection by entering:

vts < scripts/vts_test/test_script_groundToImage1 on the command line.

To run all of the files in the "./scripts/vts_test" directory you can source the C shell
script do_all_stub_single (source do_all_stub_single). 

The script do_all_stub_single will 1) run all the scripts in "./scripts/vts_test", 2) run
the unix2dos command on the output files located in the "./results/test" directory to 
convert to DOS format, 3) zip the converted files, 4) delete the converted files and 
save a copy of the screen output (stdout) to a file in the "." directory that is named 
with the Julian date and time (i.e. 182-1545).

The test script "./scripts/vts_debug/test_script_all" will issue at least one of each 
of the available commands. This file will need to be edited to specify the correct ISD 
file.

-----
NOTES:

1) The directory structure has changed to mimic the Microsoft "project" requirements. 
Running make from the top most vts directory will issue a make in each appropriate 
subdirectory. The "make clean_all" command will issue a "make clean" in the appropriate 
subdirectories. The vts executable will be deposited at the top most vts directory.

2) The debugging scripts located in ./scripts/vts_debug including the "test_script_all" 
script needs to be edited to run properly.

3) A string has been provided to temporally hold the sensor model state between API 
calls. This state string allows the vts to hold a state that was created by the sensor 
model and then allow the vts to reload the state into the sensor model. Take a look at 
the script "test_script_convertISDToSensorModelState" located in "./scripts/vts_test".

-----
VERSIONS CHANGES:

VTS Version CSM3.0.1.0:  Jan 28,2013
      First Offical release for CSM version 3.0.1 
      new vts commands: vtsAddIsdParam and vtsGetIsdParam


Version CSM3.0.1pre4:    Jan 23, 2013

   vts.cpp and StubSensorModel.cpp:
      Modified thrown-error handling to sensor model calls and to plungin calls.

      Changed getAllSensorPartials(1&2) and getCrossCovarianceMatrix to add 
      versitility to vector sizes of return arguments.

   vts_isd.cpp: 
      In parseTre, changed call to setTre to handle TREs containing embedded NULLs.


Version CSM3.0.1pre3:    Jan 10, 2013
   This version incorporates the latest C++ reformatting CRs based and on the 
   19-Dec_2012 version of the software prototype 

   This version is not intended to be a full release, due to reformatting 
   changes still pending. 

   Included "Makefile"s for Unix and Linux are now compatible with "gmake" instead of "make".

Version CSM3.0.1pre2:    Dec 19, 2012
   This version incorporates the latest C++ reformatting CRs based and on the 
   19-Dec_2012 version of the software prototype 

   Note that this pre2 release of VTS is only compatible with the four parameter 
   covariance model - the Linear Decay model has not yet been implemented.

Version CSM3.0.1pre1:
   This version incorporates the latest C++ reformatting CRs based on the 30-Oct-2012 
   CSMWG CCB subgroup meeting. 
   This version is not intended to be a full release, due to reformatting 
   changes still pending. 

Version CSM3.0.1pre:
   This version incorporates the C++ reformatting CRs.
   This version is not intended to be a full release, due to reformatting 
   changes still pending. 

Version CSM3.0.1:
   Thread testing added.  See README_threadTesting.txt file.

   Changed processing of vtsReadISD20File and vtsReadISD21File to process 
      large NITF files ( between 2GB and 4GB).
   Expanded large NITF processing to handle large pointers to DES records 
      at the end of large files

Version CSM3.0.0:

     a) Initial release of a CSM API 3.0 VTS.

-----------------------------------------------------------------------------------------
end of README_FIRST.txt file.
