10-Jan-2007

VTS GUI Beta

If you have a problem or a question call me (Len Tomko  937-476-2670) or
email me at leonard.tomko@gd-ais.com.

----------------------------------------------------------------------------

This version of the CSM GUI is written in java so that it is cross platform
and will run on all the platforms that the vts code will compile. (Sun, Gcc,
Windows, and Linux).

This version of the CSM GUI is a wrapper program for the vts program.  It
will run a verion of the vts program and pass command to the code and display
the results in the GUI.

----------------------------------------------------------------------------

Requirements:
This code was written under and requires java 1.4.2 or greater.

This code requires a vts binary and associaled libraries to be availible to
be run in the system path.

----------------------------------------------------------------------------

To compile this code type:
	javac csm_gui.java FontChooser2.java WindowUtilities.java

Run the code with the command.
	java csm_gui

----------------------------------------------------------------------------
end of README.txt file.
